# Random-Password-Gen-BenW
<h2> JS practice </h2>

![image](https://user-images.githubusercontent.com/64148154/177861886-a2eabe81-80d0-4fba-8eb9-f0a8139488d5.png)
