import React from "react";
import "./style.css";
import Menu from "./menuApi";
import MenuCard from "./MenuCard";
import Navbar from "./Navbar";

function Resturant  ()  {

  return (
    <>
      <Navbar  />
      <MenuCard  />
    </>
  );
};

export default Resturant;
