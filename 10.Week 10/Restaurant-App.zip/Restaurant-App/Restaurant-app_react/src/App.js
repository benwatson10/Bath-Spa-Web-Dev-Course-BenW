import React from "react";
import Resturant from "./component/Basics/Resturant.jsx";


function App () {
  return  (
    <>
    <navbar />,
    <Resturant />
    </>);
  
};

export default App;
